#!/bin/sh

file=`cat rockyou.txt | grep z$`

echo "Output:"

echo "$file"
