#!/bin/bash

for ((i=1;i<=5;i++))

do

echo "Iteration: $i"

done
