#!/bin/bash

for item in apple banana grape papaya mango 

do 

echo "Fruit: $item"

done 
