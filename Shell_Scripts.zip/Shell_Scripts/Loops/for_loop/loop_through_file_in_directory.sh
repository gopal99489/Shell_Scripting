#!/bin/bash

DIR="/home/mike/"

for file in "$DIR"/*

do

echo "processing $file"

done
