#!/bin/bash

arr=("apple" "banana" "cherry" "grape" "papaya")

for fruit in "${arr[@]}"

do

echo "Fruit: $fruit"

done
