#!/bin/bash

for num in {1..5}

do

echo "Number: $num"

done
