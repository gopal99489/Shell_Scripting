#!/bin/bash

for file in $(ls)

do

echo "File: $file"

done
