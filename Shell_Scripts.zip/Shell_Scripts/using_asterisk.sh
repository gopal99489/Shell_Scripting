#!/bin/sh

file=`cat fruit.txt | grep ber*y`

echo "Output:"

echo "$file"
