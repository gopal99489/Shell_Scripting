#!/bin/sh

file=`cat rockyou.txt | grep go.al`

echo "Output:"

echo "$file"
