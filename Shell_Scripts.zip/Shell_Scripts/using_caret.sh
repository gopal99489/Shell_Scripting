#!/bin/sh

file=`cat rockyou.txt | grep ^G`

echo "Output:"

echo "$file"
