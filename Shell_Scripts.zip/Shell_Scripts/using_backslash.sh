#!/bin/sh

file=`cat fruit.txt | grep "\ "`

echo "Output:"

echo "$file"
